import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import ServiceDetail from './pages/ServiceDetail';
import References from './pages/References';
import ContactPage from './pages/ContactPage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/kurumsal" element={<About />} />
        <Route path="/hizmetler" element={<Services />} />
        <Route path="/hizmetler/:id" element={<ServiceDetail />} />
        <Route path="/referanslar" element={<References />} />
        <Route path="/iletisim" element={<ContactPage />} />
      </Routes>
    </Router>
  );
}

export default App;
