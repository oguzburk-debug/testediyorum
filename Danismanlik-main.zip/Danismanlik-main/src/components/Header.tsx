import { ShoppingCart, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed w-full bg-white/95 backdrop-blur-sm shadow-sm z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-3 rounded-full">
              <ShoppingCart className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Burak Oğuz</h1>
              <p className="text-xs text-gray-600">E-Ticaret Danışmanlığı</p>
            </div>
          </div>

          {/* Menü */}
          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => scrollToSection('hizmetler')}
              className="text-gray-700 hover:text-cyan-500 transition-colors font-medium"
            >
              Hizmetler
            </button>
            <button
              onClick={() => scrollToSection('hakkimizda')}
              className="text-gray-700 hover:text-cyan-500 transition-colors font-medium"
            >
              Hakkımızda
            </button>
            <button
              onClick={() => scrollToSection('iletisim')}
              className="bg-cyan-500 text-white px-6 py-2.5 rounded-lg hover:bg-cyan-600 transition-all shadow-md hover:shadow-lg font-medium"
            >
              İletişime Geç
            </button>
          </div>

          {/* Mobil Menü Butonu */}
          <button
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobil Menü */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-4 border-t border-gray-200">
            <button
              onClick={() => scrollToSection('hizmetler')}
              className="block w-full text-left text-gray-700 hover:text-cyan-500 transition-colors font-medium"
            >
              Hizmetler
            </button>
            <button
              onClick={() => scrollToSection('hakkimizda')}
              className="block w-full text-left text-gray-700 hover:text-cyan-500 transition-colors font-medium"
            >
              Hakkımızda
            </button>
            <button
              onClick={() => scrollToSection('iletisim')}
              className="block w-full text-left bg-cyan-500 text-white px-6 py-2.5 rounded-lg hover:bg-cyan-600 transition-all font-medium"
            >
              İletişime Geç
            </button>
          </div>
        )}
      </nav>
    </header>
  );
}
