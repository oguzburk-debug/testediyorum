import { ShoppingCart, Facebook, Instagram, Linkedin, Twitter } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-2 rounded-lg">
                <ShoppingCart className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Burak Oğuz</h3>
                <p className="text-xs text-gray-400">E-Ticaret Danışmanlığı</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              E-ticaret işinizi büyütmek için modern tasarımlar, güçlü altyapılar ve kesintisiz destek sunuyoruz.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-4">Hizmetler</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Ödeme Entegrasyonu</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Özel Tasarım & Revize</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Özel Proje Çözümleri</a></li>
              <li><a href="#" className="hover:text-white transition-colors">SEO Optimizasyonu</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">İletişim</h4>
            <p className="text-gray-400 text-sm">Telefon: 0553 552 22 13</p>
            <p className="text-gray-400 text-sm mt-1">
              Adres: Çamlık Mah. Cihan Sk. No: 12-16A İç Kapı No: 7, Çekmeköy/İstanbul
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-4">Bizi Takip Edin</h4>
            <div className="flex space-x-3">
              <a href="#" className="bg-gray-700 p-2 rounded-lg hover:bg-cyan-500 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-700 p-2 rounded-lg hover:bg-cyan-500 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-700 p-2 rounded-lg hover:bg-cyan-500 transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-700 p-2 rounded-lg hover:bg-cyan-500 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
            <div className="mt-4">
              <p className="text-gray-400 text-sm mb-2">E-posta Bülteni</p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="E-posta adresiniz"
                  className="flex-1 px-3 py-2 rounded-l-lg bg-gray-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
                <button className="bg-cyan-500 px-4 py-2 rounded-r-lg hover:bg-cyan-600 transition-colors text-sm font-semibold">
                  Abone Ol
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; {currentYear} Burak Oğuz. Tüm hakları saklıdır.</p>
          <p className="mt-2">E-Ticaret Danışmanlığı & Kurulum</p>
        </div>
      </div>
    </footer>
  );
}
