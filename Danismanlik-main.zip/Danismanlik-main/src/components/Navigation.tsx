import { Link } from 'react-router-dom';
import { Zap } from 'lucide-react';

export default function Navigation() {
  return (
    <nav className="fixed top-0 w-full backdrop-blur-xl bg-white/5 border-b border-white/10 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition">
          <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-full flex items-center justify-center shadow-lg">
            {/* Minimal simge: BO monogram */}
            <span className="font-bold text-white text-lg">BO</span>
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-xl text-white">Burak Oğuz</span>
            <span className="text-xs text-gray-300">E-Ticaret Danışmanlığı</span>
          </div>
        </Link>

        {/* Menü */}
        <div className="hidden md:flex items-center gap-8">
          <Link to="/" className="text-gray-300 hover:text-cyan-400 transition font-medium text-sm">
            Anasayfa
          </Link>
          <Link to="/kurumsal" className="text-gray-300 hover:text-cyan-400 transition font-medium text-sm">
            Kurumsal
          </Link>
          <Link to="/hizmetler" className="text-gray-300 hover:text-cyan-400 transition font-medium text-sm">
            Hizmetler
          </Link>
          <Link to="/referanslar" className="text-gray-300 hover:text-cyan-400 transition font-medium text-sm">
            Referanslar
          </Link>
          <Link to="/iletisim" className="px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg font-semibold hover:shadow-lg hover:shadow-cyan-500/50 transition-all text-white">
            İletişim
          </Link>
        </div>
      </div>
    </nav>
  );
}
