import {
  Settings,
  Palette,
  ShoppingBag,
  ArrowRight,
  CheckCircle,
  TrendingUp,
  Users,
  Rocket
} from 'lucide-react';

const services = [
  {
    icon: Settings,
    title: 'Profesyonel Kurulum',
    description:
      'E-ticaret altyapınızı uçtan uca kuruyor, tüm teknik yükü üzerinizden alıyoruz.',
    features: [
      'SSL & Güvenlik',
      'Yüksek Performans Hosting',
      'Yedekleme & Firewall',
      'Teknik Destek'
    ],
    note: 'Sağlam altyapı = Sürdürülebilir satış',
    color: 'blue'
  },
  {
    icon: Palette,
    title: 'Markaya Özel Tasarım',
    description:
      'Hazır şablonlar değil, markanızın ruhuna uygun tasarımlar geliştiriyoruz.',
    features: [
      'Mobil Öncelikli',
      'SEO Uyumlu',
      'Hızlı Yükleme',
      'Dönüşüm Odaklı UI'
    ],
    note: 'Tasarım satışı doğrudan etkiler',
    color: 'green'
  },
  {
    icon: ShoppingBag,
    title: 'Pazaryeri Entegrasyonları',
    description:
      'Tüm satış kanallarınızı tek panelden yönetmenizi sağlıyoruz.',
    features: [
      'Trendyol & Hepsiburada',
      'N11 & Çiçeksepeti',
      'Amazon Global',
      'Otomatik Stok & Fiyat'
    ],
    note: 'Çok kanal = Daha fazla ciro',
    color: 'orange'
  }
];

const colors = {
  blue: 'from-blue-500 to-blue-600',
  green: 'from-green-500 to-green-600',
  orange: 'from-orange-500 to-orange-600'
};

export default function Services() {
  return (
    <section id="hizmetler" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-20">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            E-Ticarette Uçtan Uca Çözümler
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Sadece site kurmuyoruz. Satış yapan, ölçeklenebilir ve güçlü
            e-ticaret sistemleri inşa ediyoruz.
          </p>
        </div>

        {/* Services */}
        <div className="grid lg:grid-cols-3 gap-10 mb-24">
          {services.map((service, i) => {
            const Icon = service.icon;
            return (
              <div
                key={i}
                className="group bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
              >
                <div
                  className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${colors[service.color]} flex items-center justify-center mb-6`}
                >
                  <Icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-2xl font-bold mb-4">
                  {service.title}
                </h3>

                <p className="text-gray-600 mb-6">
                  {service.description}
                </p>

                <ul className="space-y-3 mb-6">
                  {service.features.map((f, idx) => (
                    <li key={idx} className="flex items-center text-gray-700">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                      {f}
                    </li>
                  ))}
                </ul>

                <div className="bg-gray-50 p-4 rounded-xl text-sm text-gray-700 mb-6">
                  <strong>Danışman Notu:</strong> {service.note}
                </div>

                <button className="w-full py-3 rounded-xl font-semibold text-white bg-gray-900 hover:bg-gray-800 transition">
                  Detaylı Bilgi Al
                </button>
              </div>
            );
          })}
        </div>

        {/* Process */}
        <div className="grid md:grid-cols-4 gap-8 text-center mb-24">
          {[
            { icon: Users, title: 'Analiz', desc: 'İş modelinizi inceleriz' },
            { icon: Palette, title: 'Tasarım', desc: 'Markaya özel UI/UX' },
            { icon: Settings, title: 'Kurulum', desc: 'Tüm teknik altyapı' },
            { icon: TrendingUp, title: 'Büyütme', desc: 'Satış & optimizasyon' }
          ].map((step, i) => {
            const Icon = step.icon;
            return (
              <div key={i}>
                <Icon className="w-10 h-10 mx-auto mb-4 text-gray-900" />
                <h4 className="text-lg font-bold mb-2">{step.title}</h4>
                <p className="text-gray-600 text-sm">{step.desc}</p>
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-3xl p-12 text-center text-white">
          <Rocket className="w-12 h-12 mx-auto mb-6" />
          <h3 className="text-3xl font-bold mb-4">
            E-Ticaretinizi Bir Üst Seviyeye Taşıyalım
          </h3>
          <p className="text-gray-300 mb-8">
            Ücretsiz danışmanlık ve analiz için hemen bizimle iletişime geçin.
          </p>
          <button className="bg-white text-gray-900 px-8 py-4 rounded-xl font-bold hover:bg-gray-100 transition">
            Ücretsiz Analiz Al
          </button>
        </div>
      </div>
    </section>
  );
}
