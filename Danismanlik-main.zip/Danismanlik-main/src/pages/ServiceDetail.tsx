import { useParams, Link } from 'react-router-dom';
import {
  ArrowLeft,
  CheckCircle,
  ShoppingCart,
  Lightbulb,
  BarChart3,
  Globe,
  Package,
  Code,
  Palette,
  Zap
} from 'lucide-react';
import Navigation from '../components/Navigation';

export default function ServiceDetail() {
  const { id } = useParams();

  const services: { [key: string]: any } = {
    'eticaret-web-sitesi': {
      title: 'E-Ticaret Web Sitesi',
      icon: ShoppingCart,
      color: 'from-cyan-500 to-blue-600',
      longDesc:
        'E-ticaret web siteniz için en modern teknolojileri kullanarak tam kapsamlı bir çözüm sunuyoruz. Kurulumdan tasarıma, ödeme sistemlerinden ürün yönetimine kadar tüm süreci uçtan uca ele alıyoruz.',
      features: [
        'Responsive ve mobil uyumlu tasarım',
        'Güvenli ödeme entegrasyonları',
        'Ürün ve stok yönetimi',
        'Sipariş takip sistemi',
        'SEO altyapısı',
        'Yüksek hız optimizasyonu',
        'Ölçeklenebilir yapı',
        'Teknik destek'
      ],
      benefits: [
        'Satış süreçleri düzenli hale gelir',
        'Müşteri deneyimi iyileşir',
        'Operasyonel yük azalır',
        'Uzun vadeli büyüme sağlanır'
      ]
    },

    'sosyal-medya-reklam': {
      title: 'Sosyal Medya Reklam Yönetimi',
      icon: Lightbulb,
      color: 'from-indigo-500 to-purple-600',
      longDesc:
        'Facebook, Instagram ve TikTok reklamlarında hedef kitle odaklı stratejiler geliştiriyoruz. Reklam bütçesini doğru yönlendirerek sürdürülebilir sonuçlar elde etmenizi sağlıyoruz.',
      features: [
        'Platform bazlı reklam yönetimi',
        'Hedef kitle analizi',
        'Kreatif içerik planlama',
        'A/B test süreçleri',
        'Dönüşüm optimizasyonu',
        'Raporlama ve analiz'
      ],
      benefits: [
        'Doğru kitleye ulaşım',
        'Bütçe verimliliği',
        'Marka bilinirliği artışı',
        'Ölçülebilir sonuçlar'
      ]
    },

    'google-reklam': {
      title: 'Google Reklam Yönetimi',
      icon: BarChart3,
      color: 'from-orange-500 to-rose-600',
      longDesc:
        'Google Ads üzerinde satış ve dönüşüm odaklı kampanyalar oluşturuyoruz. Arama niyeti yüksek kullanıcıları hedefleyerek verimli trafik sağlıyoruz.',
      features: [
        'Search & Shopping kampanyaları',
        'Anahtar kelime analizi',
        'Dönüşüm takibi',
        'Reklam metni optimizasyonu',
        'Bütçe yönetimi',
        'Detaylı raporlama'
      ],
      benefits: [
        'Hızlı geri dönüş',
        'Satın alma niyetli trafik',
        'Reklam maliyet kontrolü',
        'Net performans ölçümü'
      ]
    },

    'kurum-web-sitesi': {
      title: 'Kurumsal Web Sitesi',
      icon: Globe,
      color: 'from-emerald-500 to-teal-600',
      longDesc:
        'Kurumsal kimliğinizi doğru yansıtan, güven veren ve profesyonel web siteleri tasarlıyoruz. Dijital vitrininizi güçlendiriyoruz.',
      features: [
        'Kurumsal tasarım',
        'Mobil uyumlu yapı',
        'İletişim ve form entegrasyonları',
        'SEO uyumlu altyapı',
        'İçerik yönetim sistemi'
      ],
      benefits: [
        'Güven algısı artar',
        'Kurumsal imaj güçlenir',
        'İletişim kolaylaşır'
      ]
    },

    'seo': {
      title: 'SEO Hizmeti',
      icon: Package,
      color: 'from-yellow-500 to-orange-600',
      longDesc:
        'Arama motorlarında sürdürülebilir görünürlük sağlamak için teknik ve içerik bazlı SEO çalışmaları yürütüyoruz.',
      features: [
        'Anahtar kelime analizi',
        'Teknik SEO düzenlemeleri',
        'İçerik optimizasyonu',
        'Site hızı iyileştirme',
        'Aylık performans raporu'
      ],
      benefits: [
        'Organik trafik artışı',
        'Uzun vadeli görünürlük',
        'Reklam bağımlılığının azalması'
      ]
    },

    'pazaryeri-eihracat': {
      title: 'Pazaryeri & E-İhracat',
      icon: ShoppingCart,
      color: 'from-pink-500 to-red-600',
      longDesc:
        'Amazon, eBay ve Avrupa pazaryerleri başta olmak üzere e-ihracat süreçlerinizi profesyonel şekilde yönetiyoruz.',
      features: [
        'Hesap açılışları',
        'Ürün listeleme',
        'Fiyatlandırma stratejisi',
        'Sipariş ve operasyon yönetimi'
      ],
      benefits: [
        'Yeni pazarlara erişim',
        'Gelir çeşitliliği',
        'Ölçeklenebilir satış'
      ]
    },

    'ozel-proje-yazilim': {
      title: 'Özel Yazılım Projeleri',
      icon: Code,
      color: 'from-blue-500 to-indigo-600',
      longDesc:
        'İş süreçlerinize özel yazılım çözümleri geliştiriyoruz. Mevcut sistemlerinizi daha verimli hale getiriyoruz.',
      features: [
        'İhtiyaç analizi',
        'Custom yazılım geliştirme',
        'API entegrasyonları',
        'Bakım ve destek'
      ],
      benefits: [
        'Operasyonel verimlilik',
        'Hata oranı düşüşü',
        'Ölçeklenebilir sistemler'
      ]
    },

    'ozel-tasarim-css': {
      title: 'Özel Tasarım & CSS Revize',
      icon: Palette,
      color: 'from-fuchsia-500 to-orange-500',
      longDesc:
        'Mevcut sitenizin tasarımını modern standartlara taşıyoruz. Kullanıcı deneyimini iyileştiriyoruz.',
      features: [
        'UI/UX revizyonları',
        'Responsive iyileştirme',
        'CSS optimizasyonu',
        'Performans artırımı'
      ],
      benefits: [
        'Modern görünüm',
        'Daha yüksek dönüşüm',
        'Kullanıcı memnuniyeti'
      ]
    },

    'site-kurulum': {
      title: 'Site Kurulum Hizmeti',
      icon: Zap,
      color: 'from-red-500 to-orange-600',
      longDesc:
        'Yeni web sitenizin tüm teknik kurulum sürecini uçtan uca yönetiyoruz.',
      features: [
        'Domain & hosting kurulumu',
        'SSL ve güvenlik',
        'Temel SEO ayarları',
        'Yayın öncesi kontroller'
      ],
      benefits: [
        'Sorunsuz başlangıç',
        'Doğru teknik altyapı',
        'Zaman tasarrufu'
      ]
    }
  };

  const service = services[id || ''];
  const Icon = service?.icon;

  if (!service) {
    return (
      <div className="min-h-screen bg-slate-900 text-white">
        <Navigation />
        <div className="pt-32 text-center">
          <h1 className="text-3xl font-bold">Hizmet bulunamadı</h1>
          <Link to="/hizmetler" className="text-cyan-400 mt-4 inline-block">
            Hizmetlere geri dön
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <Navigation />

      <section className="pt-32 pb-20 px-6">
        <div className="max-w-6xl mx-auto">
          <Link to="/hizmetler" className="inline-flex items-center gap-2 text-gray-400 hover:text-cyan-400 mb-10">
            <ArrowLeft className="w-4 h-4" /> Hizmetlere Geri Dön
          </Link>

          <div className="grid md:grid-cols-2 gap-14 mb-20">
            <div>
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-6`}>
                <Icon className="w-8 h-8" />
              </div>
              <h1 className="text-5xl font-bold mb-6">{service.title}</h1>
              <p className="text-lg text-gray-300 leading-relaxed">{service.longDesc}</p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-8">
              <h2 className="text-2xl font-bold mb-6">Hizmet İçeriği</h2>
              <ul className="space-y-4">
                {service.features.map((item: string, i: number) => (
                  <li key={i} className="flex gap-3">
                    <CheckCircle className="w-5 h-5 text-cyan-400 mt-0.5" />
                    <span className="text-gray-300">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-8 mb-20">
            <h2 className="text-2xl font-bold mb-8">Bu Hizmetin Sağladıkları</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {service.benefits.map((item: string, i: number) => (
                <div key={i} className="flex gap-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${service.color} flex items-center justify-center`}>
                    <CheckCircle className="w-6 h-6" />
                  </div>
                  <p className="text-gray-300 pt-1">{item}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="text-center">
            <p className="text-gray-300 mb-6">
              Bu hizmet hakkında detaylı bilgi almak için iletişime geçebilirsiniz.
            </p>
            <Link
              to="/iletisim"
              className="inline-flex items-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-black px-10 py-4 rounded-xl font-bold transition"
            >
              İletişime Geç
            </Link>
          </div>
        </div>
      </section>

      <footer className="py-10 text-center text-gray-400 border-t border-white/10">
        © 2025 Burak Oğuz
      </footer>
    </div>
  );
}
