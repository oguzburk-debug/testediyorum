import Navigation from '../components/Navigation';
import { Link } from 'react-router-dom';
import {
  ShieldCheck,
  Headset,
  TrendingUp,
  Building2,
  ArrowRight
} from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <Navigation />

      {/* HERO */}
      <section className="pt-32 pb-24 px-6 border-b border-white/10">
        <div className="max-w-6xl mx-auto">
          <span className="text-sm tracking-widest text-cyan-400 uppercase">
            Kurumsal Bilgiler
          </span>

          <h1 className="text-5xl lg:text-6xl font-bold mt-4 leading-tight">
            E-Ticarette<br />
            <span className="text-cyan-400">Sahayı Bilen</span> Danışmanlık
          </h1>

          <p className="mt-6 text-xl text-gray-300 max-w-3xl">
            Ajans mantığıyla değil; gerçek destek, operasyon ve kriz
            tecrübesiyle şekillenen profesyonel e-ticaret danışmanlığı.
          </p>
        </div>
      </section>

      {/* PROFILE */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          
          {/* TEXT */}
          <div>
            <h2 className="text-4xl font-bold mb-6">
              Burak Oğuz
            </h2>

            <p className="text-gray-300 text-lg leading-relaxed mb-4">
              10 yıl boyunca <strong>TİCİMAX Destek Departmanı Yöneticisi</strong> olarak,
              Türkiye’nin en yoğun e-ticaret altyapılarından birinde
              <strong> 20.000+ işletme</strong> ile doğrudan temas ederek
              kurulum, destek, kriz ve operasyon süreçlerini yönettim.
            </p>

            <p className="text-gray-300 text-lg leading-relaxed mb-6">
              Bugün bu saha tecrübesini; e-ticarette sağlam altyapı kurmak,
              satış süreçlerini sorunsuz yönetmek ve büyümeyi doğru
              sistemlerle gerçekleştirmek isteyen markalar için
              birebir danışmanlığa dönüştürüyorum.
            </p>

            <div className="flex flex-wrap gap-4 mt-8">
              <div className="px-6 py-4 bg-white/5 border border-white/10 rounded-xl">
                <div className="text-2xl font-bold text-cyan-400">10+</div>
                <div className="text-sm text-gray-400">
                  Yıl Ticimax Yönetimi
                </div>
              </div>

              <div className="px-6 py-4 bg-white/5 border border-white/10 rounded-xl">
                <div className="text-2xl font-bold text-cyan-400">20.000+</div>
                <div className="text-sm text-gray-400">
                  Doğrudan Müşteri & İşletme
                </div>
              </div>
            </div>
          </div>

          {/* IMAGE */}
          <div className="relative">
            <div className="absolute inset-0 bg-cyan-500/10 rounded-3xl blur-2xl"></div>
            <img
              src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=900"
              alt="Burak Oğuz"
              className="relative z-10 rounded-3xl border border-white/10"
            />
          </div>
        </div>
      </section>

      {/* DIFFERENCE */}
      <section className="py-24 px-6 bg-slate-800/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-16">
            Danışmanlıkta Fark Yaratan Noktalar
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: ShieldCheck,
                title: 'Kriz & Risk Yönetimi',
                desc: 'Canlı sistemlerde oluşabilecek sorunları önceden öngören yaklaşım'
              },
              {
                icon: Headset,
                title: 'Destek Disiplini',
                desc: 'Kullanıcı davranışlarını bilen, önleyici destek bakış açısı'
              },
              {
                icon: TrendingUp,
                title: 'Büyüme Perspektifi',
                desc: 'Sadece kurulum değil, sürdürülebilir satış hedefi'
              },
              {
                icon: Building2,
                title: 'B2B Odaklı Çalışma',
                desc: 'Kurumsal firmalarla uyumlu süreç ve iletişim yönetimi'
              }
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <div
                  key={i}
                  className="p-8 bg-white/5 border border-white/10 rounded-2xl hover:border-cyan-400/40 transition"
                >
                  <Icon className="w-10 h-10 text-cyan-400 mb-4" />
                  <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                  <p className="text-gray-400 text-sm">{item.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">
            E-Ticarette Doğru Sistemi Kurmak İstiyorsanız
          </h2>
          <p className="text-gray-400 text-lg mb-10">
            Ajanslarla değil, sistemi bizzat yönetmiş bir danışmanla çalışın.
          </p>

          <Link
            to="/iletisim"
            className="inline-flex items-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-black px-10 py-4 rounded-xl font-bold transition"
          >
            Ücretsiz Ön Görüşme Al
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>

      <footer className="py-10 text-center text-gray-500 border-t border-white/10">
        © 2025 Burak Oğuz
      </footer>
    </div>
  );
}
