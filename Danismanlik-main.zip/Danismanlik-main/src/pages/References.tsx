import Navigation from '../components/Navigation';

export default function References() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gradient-to-tr from-orange-500/15 to-rose-500/15 rounded-full blur-[120px] animate-pulse delay-700"></div>

      <Navigation />

      <section className="pt-32 pb-20 px-6 relative z-10">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-6xl font-bold mb-4">Referanslar</h1>
          <p className="text-gray-400 mb-16 max-w-2xl text-xl">
            Başarıyla tamamladığımız projelerden bazıları
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                name: "E-Commerce Store A",
                category: "Moda & Aksesuar",
                growth: "+320% Satış Artışı",
                testimonial: "E-Ticaret Pro ile satışlarımız 3 ayda 3 katına çıktı."
              },
              {
                name: "E-Commerce Store B",
                category: "Elektronik",
                growth: "+280% Satış Artışı",
                testimonial: "Profesyonel kurulum ve tasarımla müşteri memnuniyeti arttı."
              },
              {
                name: "E-Commerce Store C",
                category: "Güzellik Ürünleri",
                growth: "+350% Satış Artışı",
                testimonial: "Pazaryeri entegrasyonu iş yükümüzü çok azalttı."
              },
              {
                name: "E-Commerce Store D",
                category: "Spor Malzemeleri",
                growth: "+290% Satış Artışı",
                testimonial: "Burak Oğuz'un danışmanlığı çok değerliydi."
              },
              {
                name: "E-Commerce Store E",
                category: "Ev & Bahçe",
                growth: "+310% Satış Artışı",
                testimonial: "Tasarımdan pazaryeri entegrasyonuna kadar her şey mükemmel."
              },
              {
                name: "E-Commerce Store F",
                category: "Kitap & Medya",
                growth: "+270% Satış Artışı",
                testimonial: "Çok profesyonel bir ekip, kesinlikle tavsiye ederim."
              }
            ].map((ref, i) => (
              <div key={i} className="p-8 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl hover:border-white/30 transition-all">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl"></div>
                  <div>
                    <h4 className="font-bold text-white">{ref.name}</h4>
                    <p className="text-xs text-gray-400">{ref.category}</p>
                  </div>
                </div>
                <div className="mb-4 p-3 bg-white/5 rounded-lg">
                  <p className="text-cyan-400 font-semibold text-sm">{ref.growth}</p>
                </div>
                <p className="text-gray-300 text-sm italic">"{ref.testimonial}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="py-12 px-6 border-t border-white/10 text-center text-gray-400 relative z-10">
        © 2025 E-Ticaret Pro – Burak Oğuz
      </footer>
    </div>
  );
}
