import { ShoppingCart, Lightbulb, BarChart3, Globe, Package, Code, Palette, Zap, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import Navigation from '../components/Navigation';

export default function Services() {
  const services = [
    {
      id: 'eticaret-web-sitesi',
      icon: ShoppingCart,
      title: "E-Ticaret Web Sitesi",
      desc: "E-ticaret sitenizi kuruyor, düzenliyor ve yönetiyoruz; lider markaların ayrıcılıklarıyla sitenizi hayata geçiriyoruz.",
      color: "from-cyan-500 to-blue-600"
    },
    {
      id: 'sosyal-medya-reklam',
      icon: Lightbulb,
      title: "Sosyal Medya Reklam Yönetimi",
      desc: "Uzman ekibimizle sosyal medya reklamlarınızı yönetiyor, performans odaklı stratejilerle marka değerinizin yükselmesini sağlıyoruz.",
      color: "from-blue-500 to-purple-600"
    },
    {
      id: 'google-reklam',
      icon: BarChart3,
      title: "Google Reklam Yönetimi",
      desc: "Google ADS ile satışlarınızı artırıyor, doğru bütçe ve hedef kitle yönetimiyle başarıya ulaşmanızı sağlıyoruz.",
      color: "from-orange-500 to-rose-600"
    },
    {
      id: 'kurum-web-sitesi',
      icon: Globe,
      title: "Kurum Web Sitesi",
      desc: "İşletmenizin prestijini artırmak için özel veya hazır yazılım çözümleri ile kurumsal web sitenizi oluşturuyoruz.",
      color: "from-green-500 to-teal-600"
    },
    {
      id: 'seo',
      icon: Package,
      title: "SEO",
      desc: "Arama motoru optimizasyonu ile web sitenizi üst sıralara taşıyarak organik trafik ve satışlarınızı artırıyoruz.",
      color: "from-yellow-500 to-orange-600"
    },
    {
      id: 'pazaryeri-eihracat',
      icon: ShoppingCart,
      title: "Pazaryeri ve E-İhracat",
      desc: "E-ticaretinizi yurtdışına açıyor, Amazon, eBay, Allegro, Zalando, Ozon, Etsy ve daha birçok platformda süreçlerinizi yönetiyoruz.",
      color: "from-pink-500 to-red-600"
    },
    {
      id: 'ozel-proje-yazilim',
      icon: Code,
      title: "Özel Proje Yazılım",
      desc: "İşletmenizin özel ihtiyaçlarına uygun kustom yazılım çözümleri geliştiriyoruz. CRM, muhasebe, envanter yönetimi ve daha fazlası.",
      color: "from-indigo-500 to-blue-600"
    },
    {
      id: 'ozel-tasarim-css',
      icon: Palette,
      title: "Özel Tasarım CSS Revize",
      desc: "Web sitenizin tasarımını yenileyin, renk şemasını güncelleyin ve modern tasarım trendlerine uyarlayın.",
      color: "from-pink-500 to-orange-500"
    },
    {
      id: 'site-kurulum',
      icon: Zap,
      title: "Site Kurulum",
      desc: "Yeni web sitenizin sıfırdan kurulması. Domain, hosting, tasarım ve yayınlanması gibi tüm adımları biz yönetiyoruz.",
      color: "from-red-500 to-orange-600"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gradient-to-tr from-orange-500/15 to-rose-500/15 rounded-full blur-[120px] animate-pulse delay-700"></div>

      <Navigation />

      <section className="pt-32 pb-20 px-6 relative z-10">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-6xl font-bold mb-4">Hizmetlerimiz</h1>
          <p className="text-gray-400 mb-16 max-w-2xl text-xl">
            E-ticaret işiniz için ihtiyacınız olan tüm çözümler tek çatı altında
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => {
              const Icon = service.icon;
              return (
                <Link
                  key={service.id}
                  to={`/hizmetler/${service.id}`}
                  className="group p-8 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl
                  hover:-translate-y-2 hover:shadow-2xl hover:shadow-black/40 hover:border-white/20 transition-all duration-300"
                >
                  <div
                    className={`w-14 h-14 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center mb-6`}
                  >
                    <Icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{service.title}</h3>
                  <p className="text-gray-400 mb-4">{service.desc}</p>
                  <div className="flex items-center gap-2 text-cyan-400 font-semibold group-hover:gap-3 transition-all">
                    Detayları Gör
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <footer className="py-12 px-6 border-t border-white/10 text-center text-gray-400 relative z-10">
        © 2025 E-Ticaret Pro – Burak Oğuz
      </footer>
    </div>
  );
}
