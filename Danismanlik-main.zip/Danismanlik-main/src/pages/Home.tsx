import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  TrendingUp,
  Zap,
  BarChart3,
  ChevronDown,
  ChevronUp,
  Cpu,
  BarChart,
  Truck,
  Layers,
  Clock,
  Users
} from 'lucide-react';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';

const stats = [
  { num: "250%", label: "Ortalama Büyüme", icon: TrendingUp },
  { num: "7/24", label: "Kesintisiz Destek", icon: Zap },
  { num: "15+", label: "Yıl Tecrübe", icon: BarChart3 },
];

const services = [
  { title: "E-Ticaret Web Sitesi", icon: Cpu, link: "/hizmetler/eticaret-web-sitesi" },
  { title: "Sosyal Medya Reklam", icon: BarChart, link: "/hizmetler/sosyal-medya-reklam" },
  { title: "Google Reklam Yönetimi", icon: Truck, link: "/hizmetler/google-reklam" },
  { title: "Kurumsal Web Sitesi", icon: Layers, link: "/hizmetler/kurum-web-sitesi" },
  { title: "SEO", icon: Cpu, link: "/hizmetler/seo" },
  { title: "Pazaryeri ve E-İhracat", icon: Truck, link: "/hizmetler/pazaryeri-eihracat" },
  { title: "Ödeme Entegrasyonu", icon: BarChart3, link: "/hizmetler/odeme-entegrasyonu" },
  { title: "Özel Tasarım & Revize", icon: Layers, link: "/hizmetler/ozel-tasarim-revize" },
  { title: "Özel Proje Çözümleri", icon: Cpu, link: "/hizmetler/ozel-proje-cozumleri" },
];

const processSteps = [
  { step: "Analiz", icon: Users, desc: "Sizin iş modelinizi ve hedeflerinizi derinlemesine inceliyoruz." },
  { step: "Planlama", icon: Layers, desc: "Özel stratejilerle yol haritası oluşturuyoruz." },
  { step: "Uygulama", icon: Clock, desc: "Hızlı ve etkin şekilde projeyi hayata geçiriyoruz." },
  { step: "Destek", icon: Zap, desc: "Sürekli takip ve optimize ederek maksimum sonuç sağlıyoruz." },
];

const faqs = [
  {
    question: "Neden sizinle çalışmalıyım?",
    answer:
      "Ticimax’ta 10 yıl boyunca departman yöneticiliği deneyimimle, sektörü derinlemesine biliyor ve sonuç odaklı çözümler sunuyorum. 20.000+ mutlu müşterimiz ve 15+ yıllık tecrübemizle işinizi büyütmek için buradayız.",
  },
  {
    question: "İşime nasıl katkı sağlarsınız?",
    answer:
      "Özel analiz ve hedef odaklı stratejilerle satışlarınızı artırır, marka değerinizi yükseltiriz.",
  },
  {
    question: "Projelerim ne kadar sürede tamamlanır?",
    answer:
      "Proje kapsamına göre değişmekle birlikte ortalama 4-8 hafta içinde teslim ediyoruz.",
  },
  {
    question: "Destek hizmetleriniz nasıl çalışıyor?",
    answer:
      "7/24 teknik destek ve performans takibi ile her an yanınızdayız.",
  },
  {
    question: "Fiyatlandırma nasıl belirleniyor?",
    answer:
      "İhtiyaçlarınıza özel fiyatlandırma yapıyoruz, şeffaf ve bütçe dostu teklifler sunuyoruz.",
  },
];

const partners = [
  { name: "Partner 1", logo: "/partners/partner1.png" },
  { name: "Partner 2", logo: "/partners/partner2.png" },
  { name: "Partner 3", logo: "/partners/partner3.png" },
  { name: "Partner 4", logo: "/partners/partner4.png" },
  { name: "Partner 5", logo: "/partners/partner5.png" },
  { name: "Partner 6", logo: "/partners/partner6.png" },
];

export default function Home() {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  // Sayfa her açıldığında en üstten başlasın
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-600 via-slate-700 to-slate-800 text-white">
      <Navigation />

      <main className="max-w-7xl mx-auto px-6 pt-28 pb-20">

        {/* Başlık ve Açıklama */}
        <section className="text-center max-w-4xl mx-auto mb-24 px-4">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight leading-[1.2]">
            E-Ticaretinizi{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-orange-400 bg-clip-text text-transparent">
              Baştan Sona Profesyonelce Yönetiyoruz
            </span>
          </h1>
          <p className="mt-4 text-md md:text-lg text-gray-300 max-w-3xl mx-auto">
            İşinizi dijitalde güçlendirmek için modern tasarımlar, güçlü altyapılar ve kesintisiz destek sunuyoruz.
            <br />
            <span className="italic opacity-70">Burak Oğuz danışmanlığında 20.000+ mutlu müşteriyle güvenle ilerleyin.</span>
          </p>

          <div className="mt-10 flex justify-center gap-6 flex-wrap">
            <Link
              to="/iletisim"
              className="inline-block px-10 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl text-white font-semibold shadow-lg hover:scale-105 transition-transform duration-300"
            >
              Ücretsiz Danışma Talep Et
            </Link>
            <Link
              to="/hizmetler"
              className="inline-block px-10 py-4 border-2 border-cyan-500 rounded-xl text-cyan-400 font-semibold hover:bg-cyan-600 hover:text-white transition-colors duration-300"
            >
              Hizmetlerimizi İncele
            </Link>
          </div>
        </section>

        {/* İstatistik Kartları */}
        <section className="grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-3xl mx-auto mb-24">
          {stats.map(({ num, label, icon: Icon }, i) => (
            <div
              key={i}
              className="bg-white/10 rounded-xl shadow-md p-8 flex flex-col items-center text-center hover:bg-white/20 hover:shadow-lg hover:scale-105 transition-transform duration-300 cursor-default"
            >
              <Icon className="w-10 h-10 text-cyan-400 mb-4" />
              <div className="text-3xl font-bold text-cyan-400">{num}</div>
              <div className="text-gray-400 mt-1">{label}</div>
            </div>
          ))}
        </section>

        {/* Hizmetler */}
        <section className="max-w-6xl mx-auto mb-28 px-4">
          <h2 className="text-3xl font-bold mb-10 text-center text-white">Hizmetlerimiz</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {services.map(({ title, icon: Icon, link }, i) => (
              <Link
                to={link}
                key={i}
                className="bg-slate-700 rounded-xl p-6 flex items-center gap-5 hover:shadow-lg hover:scale-[1.04] transition duration-300"
              >
                <Icon className="w-8 h-8 text-cyan-400" />
                <span className="font-semibold text-white">{title}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* Nasıl Çalışıyoruz */}
        <section className="max-w-5xl mx-auto mb-28 px-4">
          <h2 className="text-3xl font-bold mb-12 text-center text-white">Nasıl Çalışıyoruz?</h2>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-10 text-center">
            {processSteps.map(({ step, icon: Icon, desc }, i) => (
              <div
                key={i}
                className="bg-slate-700 rounded-xl p-6 shadow-md hover:shadow-cyan-500/50 hover:scale-105 transition-transform duration-300 cursor-default"
              >
                <div className="flex justify-center mb-4 text-cyan-400">
                  <Icon className="w-12 h-12" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{step}</h3>
                <p className="text-gray-300 text-sm">{desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Pushonica Widget */}
        <section className="max-w-5xl mx-auto mb-28 px-4">
          <div className="bg-cyan-800 bg-opacity-30 p-6 rounded-xl flex flex-col md:flex-row items-center justify-between gap-4 hover:bg-cyan-700 transition duration-300">
            <div>
              <h3 className="text-2xl font-bold text-white">Pushonica ile Anında Bildirimler!</h3>
              <p className="mt-2 text-gray-200">
                Pushonica entegrasyonu ile kullanıcı etkileşimini maksimum seviyeye taşıyın ve satışlarınızı artırın.
              </p>
            </div>
            <a
              href="https://pushonica.com"
              target="_blank"
              className="inline-block px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl font-semibold text-white hover:scale-105 transition-transform duration-300"
            >
              Hemen Kullan
            </a>
          </div>
        </section>

        {/* İş Ortaklarımız */}
        <section className="max-w-6xl mx-auto mb-28 px-4">
          <h2 className="text-3xl font-bold mb-10 text-center text-white">İş Ortaklarımız</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-10 items-center justify-center">
            {partners.map(({ name, logo }, i) => (
              <div
                key={i}
                className="bg-slate-700 p-6 rounded-lg flex items-center justify-center hover:bg-cyan-700 transition-colors duration-300"
                title={name}
              >
                <img
                  src={logo}
                  alt={name}
                  className="max-h-16 object-contain grayscale hover:grayscale-0 transition duration-300"
                />
              </div>
            ))}
          </div>
        </section>

        {/* Sıkça Sorulan Sorular */}
        <section className="max-w-4xl mx-auto mb-20 px-4">
          <h2 className="text-3xl font-bold mb-10 text-center text-white">Sıkça Sorulan Sorular</h2>
          <div className="space-y-4">
            {faqs.map(({ question, answer }, i) => (
              <div
                key={i}
                className="overflow-hidden rounded-xl shadow-md hover:shadow-lg transition duration-300"
              >
                <button
                  onClick={() => toggleFaq(i)}
                  className="w-full flex justify-between items-center p-4 bg-cyan-900 hover:bg-cyan-800 transition-colors font-semibold text-cyan-300 rounded-t-xl"
                >
                  <span>{question}</span>
                  {openFaqIndex === i ? (
                    <ChevronUp className="w-5 h-5" />
                  ) : (
                    <ChevronDown className="w-5 h-5" />
                  )}
                </button>
                {openFaqIndex === i && (
                  <div className="p-4 bg-slate-900 text-gray-300 border-t border-cyan-600">
                    {answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

      </main>

      <Footer />
    </div>
  );
}
